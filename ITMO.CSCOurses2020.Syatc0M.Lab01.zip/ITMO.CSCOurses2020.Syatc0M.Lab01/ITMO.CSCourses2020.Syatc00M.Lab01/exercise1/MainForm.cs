﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITMO.CSCourses2020.Syatc00M.Lab01.Exercise1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.Sizable;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Size = new Size(300, 500);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.5;
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            this.Opacity = 1;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
