﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ITMO.CSCourses2020.Syatc00m.Lab01.Exercise2
{
    public partial class nForm : ITMO.CSCourses2020.Syatc00m.Lab01.Exercise2.MainForm
    {
        public nForm()
        {
            InitializeComponent();
        }

        private void nForm_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}
