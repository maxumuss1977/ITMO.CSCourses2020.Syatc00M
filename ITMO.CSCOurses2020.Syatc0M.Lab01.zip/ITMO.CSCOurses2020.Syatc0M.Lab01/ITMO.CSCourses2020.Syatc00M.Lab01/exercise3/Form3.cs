﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ITMO.CSCourses2020.Syatc00m.Lab01.Exercise2
{
    public partial class Form3 : ITMO.CSCourses2020.Syatc00m.Lab01.Exercise2.MainForm
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}
