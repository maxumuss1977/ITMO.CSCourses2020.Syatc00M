﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITMO.CSCourses2020.Syatc00M.Lab01.Exercise5
{
    public partial class OvalForm : Form
    {
        public OvalForm()
        {
            InitializeComponent();
        }

        private void OvalForm_Load(object sender, EventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath myPath =
                new System.Drawing.Drawing2D.GraphicsPath();
 
            myPath.AddEllipse(0, 0, this.Width-20, this.Height-20);

            Rectangle pathRect = new Rectangle(0, 0, 100, 30);
            myPath.AddRectangle(pathRect);

            Rectangle pathRect1 = new Rectangle(Width-75, 0, Width, 30);
            myPath.AddRectangle(pathRect1);


            Region myRegion = new Region(myPath);
            this.Region = myRegion;

            

        }

        private void CloseThis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
